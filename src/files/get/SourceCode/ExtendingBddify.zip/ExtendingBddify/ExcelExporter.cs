using System;
using System.Collections.Generic;
using Bddify.Core;

namespace ExtendingBddify
{
    public class ExcelExporter : IProcessor
    {
        static readonly List<Scenario> Scenarios = new List<Scenario>();

        public ProcessType ProcessType
        {
            get { return ProcessType.Report; }
        }

        static ExcelExporter()
        {
            AppDomain.CurrentDomain.DomainUnload += CurrentDomain_DomainUnload;
        }

        static void CurrentDomain_DomainUnload(object sender, EventArgs e)
        {
            // run this only once when the appdomain is unloading, that is when the last test is run
            GenerateHtmlReport();
        }

        internal static void GenerateHtmlReport()
        {
            // DIY :)
            // ToDo: Create the file, create the spreadsheet, run through the scenarios and add them to the spreadsheet
            // for each scenario run through its steps and add them along with their result underneath each scenario
            // layout the result in an easy to read and analyse way
        }

        public void Process(Scenario scenario)
        {
            Scenarios.Add(scenario);
        }
    }
}