﻿using Bddify.Core;
using Bddify.Scanners.StepScanners.ExecutableAttribute;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Bddify.ExecutableAttributes
{
    [TestClass]
    public class NonCompliantMethodNamesWithExecutableAttributes
    {
        [TestMethod]
        public void ShouldBeAbleToRunScenariosWithNonCompliantMethodNames()
        {
            this.Bddify();
        }

        void GivenSomeMethodsDoNotComplyWithBddifyMethodNameConventions()
        {
        }

        void WhenExecutableAttributeIsApplied()
        {
        }

        [Executable(ExecutionOrder.Assertion, "bddify can pickup the steps")]
        void BddifyCanPickupTheSteps()
        {
        }

        [Executable(ExecutionOrder.ConsecutiveAssertion, "which are decorated with the attribute")]
        void ThatAreDecoratedWithTheAttributes()
        {
        }
    }
}
