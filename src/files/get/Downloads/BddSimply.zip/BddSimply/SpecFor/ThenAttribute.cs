using NUnit.Framework;

namespace SpecFor
{
    public class ThenAttribute : TestAttribute
    {
    }
}