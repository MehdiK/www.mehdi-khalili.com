﻿using Bddify.Core;
using NUnit.Framework;

namespace Bddify.FluentApi
{
     [Story(
        AsA = "As a .net programmer",
        IWant = "I want to use bddify",
        SoThat = "So that BDD becomes easy and fun")]
    public class BddifySeriouslyRocks
    {
        [Test]
        public void BddifyRocks()
        {
            this.Given(_ => GivenIHaveNotUsedBddifyBefore())
                .When(_ => WhenIAmIntroducedToTheFramework())
                .Then(_ => ThenILikeItAndStartUsingIt())
                .Bddify();
        }

        [Test]
        public void BddifyEvenRocksForBddNewbies()
        {
            this.Given(_ => GivenIAmNewToBdd())
                    .And(_ => AndIHaveNotUsedBddifyBefore())
                .When(_ => WhenIAmIntroducedToTheFramework())
                .Then(_ => ThenILikeItAndStartUsingIt())
                    .And(_ => AndILearnBddThroughBddify())
                .Bddify();
        }

        void GivenIHaveNotUsedBddifyBefore()
        {
        }

        void GivenIAmNewToBdd()
        {
        }

        void AndIHaveNotUsedBddifyBefore()
        {
        }

        void WhenIAmIntroducedToTheFramework()
        {
        }

        void ThenILikeItAndStartUsingIt()
        {
        }

        void AndILearnBddThroughBddify()
        {
        }
    }
}
