using Bddify.Core;
using Bddify.Processors;
using Bddify.Reporters;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExtendingBddify
{
    public static class BddifyExtension
    {
        public static void Bddify(this object testObject)
        {
            new Bddifier(
                testObject,
                new AnotherMethodNameScanner(),
                new IProcessor[]
                    {
                        new ExceptionHandler(Assert.Inconclusive), 
                        new HtmlReporter()
                    })
                    .Run();
        }

        public static void BddifyWithExcelExporter(this object testObject)
        {
            new Bddifier(
                testObject,
                new AnotherMethodNameScanner(),
                new IProcessor[]
                    {
                        new TestRunner(ex => ex.GetType().Name.Contains("Inconclusive")),
                        new ExcelExporter()
                    })
                    .Run();
        }
    }
}