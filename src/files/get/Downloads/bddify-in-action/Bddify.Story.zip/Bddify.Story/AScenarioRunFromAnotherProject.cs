using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Bddify.Story
{
    [TestClass]
    public class AScenarioRunFromAnotherProject
    {
        [TestMethod]
        public void TellBddifyWhatStoryToUse()
        {
            new ShouldBeAbleToBddifyMyTestsVeryEasily().Bddify<BddifyRocks>();
        }
    }
}