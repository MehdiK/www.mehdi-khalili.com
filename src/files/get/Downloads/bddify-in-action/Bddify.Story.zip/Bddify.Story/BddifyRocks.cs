using Bddify.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Bddify.Story
{
    [TestClass]
    [Story(
        AsA = "As a .net programmer",
        IWant = "I want to use bddify",
        SoThat = "So that BDD becomes easy and fun")]
    public class BddifyRocks
    {
        [TestMethod]
        public void LetBddifyFindTheStory()
        {
            new ShouldBeAbleToBddifyMyTestsVeryEasily().Bddify();
        }

        [TestMethod]
        public void TellBddifyWhatStoryToUse()
        {
            new ShouldBeAbleToBddifyMyTestsVeryEasily().Bddify<BddifyRocks>();
        }
    }
}
