﻿using Bddify.Core;
using Bddify.Scanners.StepScanners;
using Bddify.Scanners.StepScanners.ExecutableAttribute;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Bddify.ExecutableAttributes
{
    [TestClass]
    public class ExcludingMethodsFromScan
    {
        [TestMethod]
        public void ShouldBeAbleToRunScenariosWithNonCompliantMethodNames()
        {
            this.Bddify();
        }

        void GivenSomeMethodsComplyWithBddifyMethodNameConventions()
        {
        }

        void AndGivenTheyAreNotRealSteps()
        {
        }

        void WhenIgnoreStepAttributeIsApplied()
        {
            WhenEzuelaIsNotSpelledLikeThisDude();
        }

        [IgnoreStep]
        void WhenEzuelaIsNotSpelledLikeThisDude()
        {
        }

        void ThenBddifyIgnoresTheMethod()
        {
        }
    }
}
