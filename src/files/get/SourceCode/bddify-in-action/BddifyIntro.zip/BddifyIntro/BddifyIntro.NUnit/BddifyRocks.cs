﻿using Bddify.Core;
using Bddify;
using NUnit.Framework;

namespace BddifyIntro.NUnit
{
    [TestFixture]
    [Story(
        AsA = "As a .net programmer",
        IWant = "I want to use bddify",
        SoThat = "So that BDD becomes easy and fun")]
    public class BddifyRocks
    {
        [Test]
        public void ShouldBeAbleToBddifyMyTestsVeryEasily()
        {
            this.Bddify();
        }

        void GivenIHaveNotUsedBddifyBefore()
        {
        }

        void WhenIAmIntroducedToTheFramework()
        {
        }

        void ThenILikeItAndStartUsingIt()
        {
        }
    }
}
