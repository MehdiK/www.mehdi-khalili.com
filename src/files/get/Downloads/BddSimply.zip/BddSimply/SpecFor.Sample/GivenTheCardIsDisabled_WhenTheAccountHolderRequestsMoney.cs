using SystemUnderTest;
using NUnit.Framework;

namespace SpecFor.Sample
{
    public class GivenTheCardIsDisabled_WhenTheAccountHolderRequestsMoney : SpecFor<Atm>
    {
        private Card _card;

        protected override Atm Given()
        {
            _card = new Card(false);
            return new Atm();
        }

        protected override void When()
        {
            Subject.RequestMoney(_card);
        }

        [Then]
        public void TheAtmShouldRetainTheCard()
        {
            Assert.That(Subject.CardIsRetained, Is.True);
        }

        [Then]
        public void TheAtmShouldSayTheCardHasBeenRetained()
        {
            Assert.That(Subject.Message, Is.EqualTo(DisplayMessage.CardIsRetained));
        }
    }
}