namespace IDisposableForCleanup
{
    using System;

    public class ForeColor : IDisposable
    {
        private readonly ConsoleColor _previousColor;

        public ForeColor(ConsoleColor foreColor)
        {
            _previousColor = Console.ForegroundColor;
            Console.ForegroundColor = foreColor;
        }

        public void Dispose()
        {
            Console.ForegroundColor = _previousColor;
        }
    }
}