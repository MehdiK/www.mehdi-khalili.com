﻿using System;
using NUnit.Framework;

namespace SpecFor
{
    [TestFixture]
    public abstract class SpecFor<T>
    {
        protected T Subject;

        [SetUp]
        public void Setup()
        {
            Console.WriteLine(typeof(T));
            Subject = Given();    
            When();
        }

        protected abstract T Given();
        protected abstract void When();
    }
}
