﻿using System;
using NUnit.Framework;

namespace Bddify.FluentApiInputParameters
{
    public class AlcoholLawsApplyToLicencedPremises
    {
        [Test]
        public void AlcoholIsNotSoldToMinorsTake1()
        {
            this.Given(_ => GivenIWasBornOn01011998())
                .When(_ => WhenIAskToBuyAlcoholInALicencedPremiseOn01012012())
                .Then(_ => ThenIDoNotGetTheAlocohol())
                    .And(_ => AndIAmWalkedOut())
                .Bddify();
        }

        [Test]
        public void AlcoholIsNotSoldToMinorsTake2()
        {
            this.Given(_ => GivenIWasBornOn01011998(), "Given I was born on 01-01-1998")
                .When(_ => WhenIAskToBuyAlcoholInALicencedPremiseOn01012012(), "When I ask to buy alcohol in a licenced permise on 01-01-2012")
                .Then(_ => ThenIDoNotGetTheAlocohol())
                    .And(_ => AndIAmWalkedOut())
                .Bddify("Alcohol is not sold to minors");
        }

        [Test]
        public void AlcoholIsNotSoldToMinorsTake3()
        {
            this.Given(_ => GivenIWasBornOn(new DateTime(1998, 1, 1)))
                .When(_ => WhenIAskToBuyAlcoholInALicencedPremiseOn(new DateTime(2012, 1, 1)))
                .Then(_ => ThenIDoNotGetTheAlocohol())
                    .And(_ => AndIAmWalkedOut())
                .Bddify("Alcohol is not sold to minors");
        }

        [Test]
        public void AlcoholIsNotSoldToMinorsTake4()
        {
            this.Given(_ => GivenIWasBornOn(new DateTime(1998, 1, 1)), "Given I was born on {0:dd-MMM-yyyy}")
                .When(_ => WhenIAskToBuyAlcoholInALicencedPremiseOn(new DateTime(2012, 1, 1)), "When I ask to buy alcohol in a licenced premise on {0:dd-MMM-yyyy}")
                .Then(_ => ThenIDoNotGetTheAlocohol())
                    .And(_ => AndIAmWalkedOut())
                .Bddify("Alcohol is not sold to minors");
        }

        [Test]
        public void AlcoholIsNotSoldToMinorsParametersNotShownInTheReportTake1()
        {
            this.Given(_ => GivenIAmAMinor(new DateTime(1998, 1, 1)))
                .When(_ => WhenIAskToBuyAlcoholInALicencedPremise())
                .Then(_ => ThenIDoNotGetTheAlocohol())
                    .And(_ => AndIAmWalkedOut())
                .Bddify("Alcohol is not sold to minors");
        }

        [Test]
        public void AlcoholIsNotSoldToMinorsParametersNotShownInTheReportTake2()
        {
            this.Given(_ => GivenIAmAMinor(new DateTime(1998, 1, 1)), false)
                .When(_ => WhenIAskToBuyAlcoholInALicencedPremise())
                .Then(_ => ThenIDoNotGetTheAlocohol())
                    .And(_ => AndIAmWalkedOut())
                .Bddify("Alcohol is not sold to minors");
        }

        private void GivenIAmAMinor(DateTime dateOfBirth)
        {
        }

        private void WhenIAskToBuyAlcoholInALicencedPremise()
        {
        }

        private void WhenIAskToBuyAlcoholInALicencedPremiseOn(DateTime occurrenceDate)
        {
        }

        private void GivenIWasBornOn(DateTime dateOfBirth)
        {
        }

        private void AndIAmWalkedOut()
        {
        }

        private void ThenIDoNotGetTheAlocohol()
        {
        }

        private void WhenIAskToBuyAlcoholInALicencedPremiseOn01012012()
        {
        }

        private void GivenIWasBornOn01011998()
        {
        }
    }
}
