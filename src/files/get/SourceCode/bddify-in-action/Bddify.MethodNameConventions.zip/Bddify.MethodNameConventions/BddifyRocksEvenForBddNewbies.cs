﻿using NUnit.Framework;

namespace Bddify.MethodNameConventions
{
    public class BddifyRocksEvenForBddNewbies
    {
        [Test]
        public void ShouldBeAbleToBddifyMyTestsVeryEasily()
        {
            this.Bddify();
        }

        void GivenIAmNewToBdd()
        {
        }

        void AndGivenIHaveNotUsedBddifyBefore()
        {
        }

        void WhenIAmIntroducedToTheFramework()
        {
        }

        void ThenILikeItAndStartUsingIt()
        {
        }

        void AndILearnBddThroughBddify()
        {
        }
    }
}