﻿using System;
using System.Collections.Generic;

namespace RefactoringUsingReSharper
{
    class Program
    {
        static void Main(string[] args)
        {
            var prg = new Program();
            var processLengthInMs = prg.DoSomethingLengthy(() => System.Threading.Thread.Sleep(2000));
            Console.WriteLine("DoSomethingLengthy took {0} milliseconds", processLengthInMs);
            Console.ReadLine();
        }

        public double DoSomethingLengthy(Action theLengthyMethod)
        {
            var startTime = DateTime.Now;

            theLengthyMethod();

            var endTime = DateTime.Now;
            return (endTime - startTime).TotalMilliseconds;
        }

        public int DoSomethingElse(IEnumerable<int> inputs)
        {
            var counter = 0;

            foreach (var input in inputs)
            {
                if (IsWrongInput(input))
                {
                    counter++;

                    if(counter > 20)
                        throw new Exception("Too many wrong input");
                }
            }

            return counter;
        }

        public int LetReSharperShine(IEnumerable<int> inputs)
        {
            var counter = 0;

            foreach (var input in inputs)
            {
                if (IsWrongInput(input))
                {
                    counter++;
                }
            }

            return counter;
        }

        public bool IsWrongInput(int input)
        {
            return (input%2 == 0);
        }
    }
}
