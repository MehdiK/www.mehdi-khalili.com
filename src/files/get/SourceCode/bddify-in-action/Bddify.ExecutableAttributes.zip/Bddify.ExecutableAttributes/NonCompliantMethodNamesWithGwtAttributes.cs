﻿using Bddify.Core;
using Bddify.Scanners.StepScanners.ExecutableAttribute;
using Bddify.Scanners.StepScanners.ExecutableAttribute.GwtAttributes;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Bddify.ExecutableAttributes
{
    [TestClass]
    public class NonCompliantMethodNamesWithGwtAttributes
    {
        [TestMethod]
        public void ShouldBeAbleToRunScenariosWithNonCompliantMethodNames()
        {
            this.Bddify("Non compliant method names with GWT attributes");
        }

        void GivenSomeMethodsDoNotComplyWithBddifyMethodNameConventions()
        {
        }

        void WhenExecutableAttributeIsApplied()
        {
        }

        [Then]
        void BddifyCanPickupTheSteps()
        {
        }

        [AndThen("which are decorated with the Given, AndGiven, When, AndWhen, Then or AndThen attributes ")]
        void ThatAreDecoratedWithTheAttributes()
        {
        }
    }
}
