using System;
using Bddify.Scanners;

namespace ExtendingBddify
{
    public class AnotherMethodNameScanner : MethodNameScanner
    {
        public AnotherMethodNameScanner()
            : base(new[]
                    {
                        new MethodNameMatcher(s => s.Equals("RunsFirstButDoesNotReportMethod", StringComparison.Ordinal), false, shouldReport:false), 
                        new MethodNameMatcher(s => s.StartsWith("When_", StringComparison.Ordinal), false),
                        new MethodNameMatcher(s => s.StartsWith("ItShould_", StringComparison.Ordinal), true)
                    })
        {
        }
    }
}