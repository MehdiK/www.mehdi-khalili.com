﻿using Bddify.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Bddify;

namespace BddifyIntro.MsTest
{
    [TestClass]
    [Story(
        AsA = "As a .net programmer",
        IWant = "I want to use bddify",
        SoThat = "So that BDD becomes easy and fun")]
    public class BddifyRocks
    {
        [TestMethod]
        public void ShouldBeAbleToBddifyMyTestsVeryEasily()
        {
            this.Bddify();
        }

        void GivenIHaveNotUsedBddifyBefore()
        {
        }

        void WhenIAmIntroducedToTheFramework()
        {
        }

        void ThenILikeItAndStartUsingIt()
        {
        }
    }
}
