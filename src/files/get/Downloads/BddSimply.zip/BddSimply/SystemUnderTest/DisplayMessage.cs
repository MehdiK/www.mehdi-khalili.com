﻿namespace SystemUnderTest
{
    public enum DisplayMessage
    {
        None = 0,
        CardIsRetained
    }
}