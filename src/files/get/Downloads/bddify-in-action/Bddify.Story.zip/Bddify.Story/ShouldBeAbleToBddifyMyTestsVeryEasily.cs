﻿namespace Bddify.Story
{
    public class ShouldBeAbleToBddifyMyTestsVeryEasily
    {
        void GivenIHaveNotUsedBddifyBefore()
        {
        }

        void WhenIAmIntroducedToTheFramework()
        {
        }

        void ThenILikeItAndStartUsingIt()
        {
        }
    }
}
