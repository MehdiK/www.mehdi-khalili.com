﻿using NUnit.Framework;

namespace Bddify.MethodNameConventions
{
    public class BddifyRocks
    {
        [Test]
        public void ShouldBeAbleToBddifyMyTestsVeryEasily()
        {
            this.Bddify();
        }

        void GivenIHaveNotUsedBddifyBefore()
        {
        }

        void WhenIAmIntroducedToTheFramework()
        {
        }

        void ThenILikeItAndStartUsingIt()
        {
        }
    }
}